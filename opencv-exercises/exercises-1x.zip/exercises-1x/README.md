<h2>
Dependencies:
</h2>  

* C++ 11+
* CMake 2.8+
* OpenCV 3.2+

<h2>
Compile project:
</h2>

To compile the project, compile the exercises:

~~~~
>> cd build
>> cmake ..
>> make
~~~~

<h2>
Run exercises:
</h2>

~~~~
>> ./exercise_11a_flatzone <input_txt_path> <input_image_path> <output_image_path>
~~~~
